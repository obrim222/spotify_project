<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="global.css" />
    <link rel="stylesheet" href="songs.css" />
    <title>Jamify songs page</title>
</head>

<body>
    <?php include_once('header.php') ?>
    <?php session_start() ?>

    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
               <input class="btn btn-primary" type="submit" name="sortArtist" value="Sort by artist">  
        </div>
    </form>

    <div class="description">
        <?php
        if (isset($_POST['sortArtist'])) {
            if ($_SESSION['ascending'] == true) {
                $_SESSION['ascending'] = false;
            } else {
                $_SESSION['ascending'] = true;
            }
        } else {
            $_SESSION['ascending'] = true;
        }

        // Ask for user's information
        $conn = mysqli_connect('localhost', 'root', '', 'jamify');
        // $query = "SELECT * FROM songs order by title asc";
        //$result = mysqli_query($conn, $query);

        if ($_SESSION['ascending'] != true) {
            // Ask for user's information
            $query = "SELECT songs.*, artists.name FROM songs inner join artists on songs.artist_id = artists.id order by artists.name desc";
            $result = mysqli_query($conn, $query);
            echo '<div class=songsContainer>';
            foreach ($result as $song) {
                echo '<div class="card p-3 songsCard">';
                echo '<span> Id: ' . ' ' . $song['id']   . '</span>';
                echo '<span> Title: ' . ' ' . $song['title'] . '</span>';
                echo '<span> Release Date: ' . ' ' . $song['release_date'] . '</span>';
                echo '<span> Artist Id: ' . ' ' . $song['artist_id'] . '</span>';
                echo '<span> Artist Name: ' . ' ' . $song['name'] . '</span>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            $query = "SELECT songs.*, artists.name FROM songs inner join artists on songs.artist_id = artists.id order by artists.name asc";

            $result = mysqli_query($conn, $query);
            echo '<div class=songsContainer>';
            foreach ($result as $song) {
                echo '<div class="card p-3 songsCard">';
                echo '<span> Id: ' . ' ' .  $song['id']   . '</span>';
                echo '<span> Title: ' . ' ' .   $song['title'] . '</span>';
                echo '<span> Release Date: ' . ' ' .   $song['release_date'] . '</span>';
                echo '<span> Artist Id: ' . ' ' . $song['artist_id'] . '</span>';
                echo '<span> Artist Name: ' . ' ' . $song['name'] . '</span>';
                echo '</div>';
            }
            echo '</div>';
        }

        ?>
    </div>

    <?php include_once('navbar.php') ?>

</body>

</html>