<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="global.css" />
    <link rel="stylesheet" href="playlists.css" />
    <title>Jamify playlists page</title>
</head>

<body>
    <?php include_once('header.php') ?>
    <?php session_start() ?>

    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
               <input class="btn btn-primary" type="submit" name="displayPlaylists" value="Display your playlists">  
        </div>
    </form>

    <div class="description">
        <?php

        $conn = mysqli_connect('localhost', 'root', '', 'jamify');

        if(isset($_POST['displayPlaylists']))
        {
            // Ask for user's information

            $query = "SELECT * FROM playlists";
            $result = mysqli_query($conn, $query);
            echo '<div class=playlistsContainer>';
            $temp = $_SESSION['id'];
          
         
            foreach($temp as $key => $value){
                echo '<span> Your User Id is: ' . " : " . $value . '</span>' . "<br>";
                echo '<span> Here are your playlists: ' . "<br>";
            }

            foreach ($result as $playlist) {
               // foreach ($temp as $key => $val) {
                if( $playlist['user_id'] == $value){
                    echo '<div class="card p-3 playlistsCard">';
                    echo '<span> Id: ' . ' ' . $playlist['id']   . '</span>';
                    echo '<span> Title: ' . ' ' . $playlist['title'] . '</span>';
                    echo '<span> Creation Date: ' . ' ' . $playlist['creation_date'] . '</span>';
                    echo '<span> User Id: ' . ' ' . $playlist['user_id'] . '</span>';
                    echo '</div>';
                }
           // }
        }
            echo '</div>';
        } 

        ?>
    </div>


    <h3>Insert a new playlist</h3>
    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
               <input class="btn btn-primary" type="submit" name="sortPlaylist" value="Add a new playlist">  
        </div>
    </form>
    <?php

    // Insert only when form is submitted
    if (isset($_POST['insertBtn'])) {

        $errors = array();

        // name, price and type must not be empty !
        if (empty($_POST['name']))
            $errors['name'] = 'Name is mandatory<br>';

        if (empty($_POST['price']))
            $errors['price'] = 'Price is mandatory<br>';
        elseif (!is_numeric($_POST['price']))
            $errors['price'] = 'Price must be a number !<br>';

        if (empty($_POST['type']))
            $errors['type'] = 'Type is mandatory<br>';

        // Insert only if no errors
        if (empty($errors)) {

            // Easier for the query
            $name = trim($_POST['name']);
            $price = trim($_POST['price']);
            $photo = trim($_POST['photo']);
            $type = trim($_POST['type']);
            $description = trim($_POST['description']);

            $conn = mysqli_connect('localhost', 'root', '', 'christmas_shop');
            $query = "INSERT INTO toys(name, price, photo, type, description)
            VALUES('$name', $price, '$photo', '$type', '$description')";

            // 2. Execute the query
            $result = mysqli_query($conn, $query);

            // INSERT/UPDATE/DELETE returns true OR false
            if ($result)
                echo 'Successfully inserted in the DB';
            else
                echo '<span style="color:red">Problem inserting in the DB</span>';
        } else {
            foreach ($errors as $errorMsg) {
                echo "<span style='color:red'>$errorMsg</span>";
            }
        }
    }
    ?>

    <form method="post">
        <input type="text" name="name" placeholder="Toy's name"><br>
        <input type="text" name="price" placeholder="Toy's price"><br>
        <select name="type" id="types">
            <option value="">--Please choose an option--</option>
            <option value="dolls">Dolls</option>
            <option value="mechanic">Mechanic</option>
            <option value="puzzle">Puzzle</option>
        </select><br>

        <input type="text" name="photo" placeholder="Photo URL"><br>
        <textarea name="description" cols="30" rows="10" placeholder="Description"></textarea><br>
        <input type="submit" name="insertBtn" value="Insert toy">
    </form>

    <?php include_once('navbar.php') ?>

</body>

</html>