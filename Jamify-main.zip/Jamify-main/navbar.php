<div class="navbar">
    <div class="navbar-btn">
        <a href="index.php">
            <i class="bi bi-house-fill"></i>
        </a>
    </div>
    <div class="navbar-btn">
        <a href="songs.php">
            <i class="bi bi-music-note"></i>
        </a>
    </div>
    <div class="navbar-btn">
        <a href="artists.php">
            <i class="bi bi-stars"></i>
        </a>
    </div>
    <div class="navbar-btn">
        <i class="bi bi-file-play-fill"></i>
    </div>
    <div class="navbar-btn">
        <a href="login.php">
            <i class="bi bi-door-open-fill"></i>
        </a>
    </div>
</div>