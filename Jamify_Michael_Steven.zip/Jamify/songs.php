<?php
session_start();
if (isset($_POST['sortArtist'])) {
    if ($_SESSION['ascending'] == true) {
        $_SESSION['ascending'] = false;
    } else {
        $_SESSION['ascending'] = true;
    }
} else {
    $_SESSION['ascending'] = true;
}


// Ask for user's information
$conn = mysqli_connect('localhost', 'root', '', 'jamify');


if ($_SESSION['ascending'] != true) {

    // Ask for user's information
    $query = "SELECT songs.*, artists.name FROM songs inner join artists on songs.artist_id = artists.id order by artists.name desc";
    $result = mysqli_query($conn, $query);
} else {
    $query = "SELECT songs.*, artists.name FROM songs inner join artists on songs.artist_id = artists.id order by artists.name asc";

    $result = mysqli_query($conn, $query);
}


// Ask for user's information
$temp = $_SESSION['id'];

$query2 = "select * from playlists where playlists.user_id IN ('" . $temp . "')";
$result2 = mysqli_query($conn, $query2);
$final_result = mysqli_fetch_all($result2, MYSQLI_ASSOC);


if (isset($_POST['submit'])) {
    $temp2 = $_SESSION['id'];

    $errors = array();

    // Insert only if no errors
    if (empty($errors)) {

        $plId = $_POST['browser'];
        $songId = $_POST['songId'];


        $conn = mysqli_connect('localhost', 'root', '', 'jamify');
        $query3 = "INSERT INTO playlist_content(playlist_id, song_id)
                VALUES('$plId', '$songId')";

        $result3 = mysqli_query($conn, $query3);
    } else {
        foreach ($errors as $errorMsg) {
            echo "<span style='color:red'>$errorMsg</span>";
        }
    }
} else {
    $result3 = [];
}


?>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="global.css" />
    <link rel="stylesheet" href="songs.css" />
    <title>Jamify songs page</title>
</head>

<body>

    <script>
        const favs = [];
    </script>

    <?php include_once('header.php') ?>

    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
            <input class="btn btn-primary" type="submit" name="sortArtist" value="Sort by artist">
        </div>
    </form>
    <div class="d-flex justify-content-center">
        <?php if (isset($_POST['submit'])) { ?>
            <?php if ($result3) { ?>
                <span style=color:green>Successfully inserted in the DB</span>
            <?php } else { ?>
                <span style=color:red>Problem inserting to the DB, record may already exist</span>
            <?php } ?>

        <?php } ?>
    </div>



    <div class="d-flex justify-content-end p-2">
        <button class="btn btn-primary" onclick="displayARRAY()" name="displayFavourites">Display</button>
    </div>
    <div class=songsContainer>
        <div class="card  p-3  songsCard">
            <div>Favourites:</div>
            <div class="result" id="result"></div>
        </div>
    </div>
    <div class=songsContainer>
        <?php foreach ($result as $song) { ?>
            <div class="card p-3 songsCard">
                <span> Title: <?= $song['title'] ?> </span>
                <span> Release Date: <?= $song['release_date'] ?></span>
                <span> Artist Name: <?= $song['name'] ?></span>
                <form action="songs.php" style="display:flex;" action="" method="POST">
                    <input type="hidden" name="songId" value="<?php echo $song['id']  ?>">
                    <label for=" browser">Add to a playlist:</label>
                    <select name="browser">
                        <?php foreach ($final_result as $key => $pl) { ?>
                            <option value="<?php echo $pl['id']  ?>"><?php echo $pl['title'] ?></option>
                        <?php  } ?>
                    </select>

                    <input type="submit" name="submit" value="add">

                </form>
                <a style="color: red;" onclick="myARRAY(<?php echo "'" . $song['title'] . "'" ?>)" id="<?php echo $song['id'] ?>"><i class=" heart pull-right"></i></a>

            </div>

        <?php  } ?>
    </div>

    <?php include_once('navbar.php') ?>

    <script>
        function myARRAY(id) {
            favs.push(id);
        }

        function displayARRAY() {
            for (var i = 0; i < favs.length; i++) {
                document.getElementById("result").innerHTML += favs[i] + "<br/>";
            }
        }
    </script>
</body>

</html>