<div class="header">
    <img src="jamify_logo.jpg">
</div>