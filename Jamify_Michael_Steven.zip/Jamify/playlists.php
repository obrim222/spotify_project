<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'jamify');

if (isset($_POST['displayPlaylists'])) {
    // Ask for user's information

    $query = "SELECT * FROM playlists";
    $result = mysqli_query($conn, $query);
    //echo '<div class=playlistsContainer>';
    $temp = $_SESSION['id'];
} else {
    $result = [];
}

if (isset($_POST['displayAllPlaylists'])) {
    // Ask for user's information

    $query = "select songs.title as songTitle, songs.release_date as songRelease, playlist_content.playlist_id as pId, playlists.title as pTitle
         from songs inner join  
         playlist_content on playlist_content.song_id = songs.id
         JOIN playlists on playlist_content.playlist_id = playlists.id";
    $result3 = mysqli_query($conn, $query);
} else {
    $result3 = [];
}

// Insert only when form is submitted
if (isset($_POST['addPlaylist'])) {
    $temp2 = $_SESSION['id'];

    $errors = array();

    if (empty($_POST['plTitle']))
        $errors['plTitle'] = 'Name is mandatory<br>';

    // Insert only if no errors
    if (empty($errors)) {
        // Easier for the query
        $name = trim($_POST['plTitle']);
        $creationDate = date('Y-m-d');
        $id = $_SESSION['id'];

        $conn = mysqli_connect('localhost', 'root', '', 'jamify');
        $query2 = "INSERT INTO playlists(title, creation_date, user_id)
                VALUES('$name', '$creationDate', '$id')";
        $result2 = mysqli_query($conn, $query2);
    } else {
        foreach ($errors as $errorMsg) {
            echo "<span style='color:red'>$errorMsg</span>";
        }
    }
} else {
    $result2 = [];
}

?>

<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="global.css" />
    <link rel="stylesheet" href="playlists.css" />
    <title>Jamify playlists page</title>
</head>

<body>
    <?php include_once('header.php') ?>

    <h3 class="d-flex justify-content-end p-2">Add a new playlist</h3>
    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
            <input type="text" name="plTitle" placeholder="Playlist title"><br>
            <input class="btn btn-primary" type="submit" name="addPlaylist" value="Add a new playlist">
        </div>
    </form>


    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
            <input class="btn btn-primary" type="submit" name="displayPlaylists" value="Display your playlists">
        </div>
    </form>

    <form action="" method="POST">
        <div class="d-flex justify-content-end p-2">
            <input class="btn btn-primary" type="submit" name="displayAllPlaylists" value="Display all playlists">
        </div>
    </form>

    <div class=playlistsContainer>
        <?php if (isset($_POST['addPlaylist'])) { ?>
            <?php if ($result2) { ?>
                <span style='color:green'>Successfully inserted in the DB </span>
            <?php } else { ?>
                <span style='color:red'> Problem inserting to the DB </span>
            <?php } ?>
        <?php } ?>
    </div>

    <div class=playlistsContainer>
        <?php foreach ($result as $playlist) { ?>
            <?php if ($playlist['user_id'] == $temp) { ?>
                <div class="card p-3 playlistsCard">
                    <span> Title: <?= $playlist['title'] ?></span>
                    <span> Creation Date: <?= $playlist['creation_date'] ?></span>
                    <span> User Id: <?= $playlist['user_id'] ?></span>
                </div>
            <?php  } ?>
        <?php  } ?>

    </div>

    <div class=playlistsContainer>
        <?php foreach ($result3 as $playlist3) { ?>
            <div class="card p-3 playlistsCard">
                <span> Playlist Id: <?= $playlist3['pId'] ?></span>
                <span> Playlists title: <?= $playlist3['pTitle'] ?></span>
                <span> Songs title: <?= $playlist3['songTitle'] ?></span>
                <span> Songs Release: <?= $playlist3['songRelease'] ?></span>
            </div>
        <?php  } ?>
    </div>

    <div class="description">
    </div>

    <?php include_once('navbar.php') ?>

</body>

</html>